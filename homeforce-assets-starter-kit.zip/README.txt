HOMEFORCE ASSET STARTER KIT

Use the folders to find approved logo variants, listing and social materials, client guides, stationery, presentations, imagery, and partner files.

Files marked as templates contain bracketed placeholders. Replace them with verified details, agent contacts, required brokerage disclosures, and listing facts before sharing or printing.

The sample property photography is AI-generated and illustrative. Do not present it as a real listing photo. Replace it with authorized photography that accurately shows the property.

The property teaser is an animated GIF. This package does not include an MP4 because an MP4 video encoder is not available in this workspace.

Print files are proof templates; confirm bleed, color mode, trim, legal requirements, and production settings with your printer and brokerage.
